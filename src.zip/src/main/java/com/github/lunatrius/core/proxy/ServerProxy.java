package com.github.lunatrius.core.proxy;

public class ServerProxy extends CommonProxy {

}
