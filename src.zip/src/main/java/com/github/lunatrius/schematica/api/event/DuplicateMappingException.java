package com.github.lunatrius.schematica.api.event;

public class DuplicateMappingException extends Exception {
    public DuplicateMappingException(final String s) {
        super(s);
    }
}
