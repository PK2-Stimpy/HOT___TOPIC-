package me.ionar.salhack.module.misc;

import me.ionar.salhack.module.Module;

public class ThrowJunkModule extends Module
{
    public ThrowJunkModule()
    {
        super("ThrowJunk", new String[] {""}, "Throws junk that you might not want in your inventory or a chest", "NONE", -1, ModuleType.MISC);
    }
}
