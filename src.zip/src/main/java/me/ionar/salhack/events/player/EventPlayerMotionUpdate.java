package me.ionar.salhack.events.player;

import me.ionar.salhack.events.MinecraftEvent;

public class EventPlayerMotionUpdate extends MinecraftEvent
{
    public EventPlayerMotionUpdate(Era p_Era)
    {
        super(p_Era);
    }
}
