package me.ionar.salhack.events.salhack;

import me.ionar.salhack.module.Module;

public class EventSalHackModuleDisable extends EventSalHackModule
{
    public EventSalHackModuleDisable(Module p_Mod)
    {
        super(p_Mod);
    }
}
