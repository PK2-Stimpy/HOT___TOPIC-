package me.ionar.salhack.events.player;

import me.ionar.salhack.events.MinecraftEvent;

public class EventPlayerResetBlockRemoving extends MinecraftEvent
{

}
