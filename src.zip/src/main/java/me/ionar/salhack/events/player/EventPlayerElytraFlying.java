package me.ionar.salhack.events.player;

import me.ionar.salhack.events.MinecraftEvent;
import net.minecraft.entity.MoverType;

public class EventPlayerElytraFlying extends MinecraftEvent
{
    public EventPlayerElytraFlying()
    {
    }
    
    public boolean Is;
}
