package me.ionar.salhack.events.blocks;

import me.ionar.salhack.events.MinecraftEvent;

public class EventGetBlockReachDistance extends MinecraftEvent
{
    public float BlockReachDistance = 0.0f;
    
    public EventGetBlockReachDistance()
    {
        super();
    }
}
