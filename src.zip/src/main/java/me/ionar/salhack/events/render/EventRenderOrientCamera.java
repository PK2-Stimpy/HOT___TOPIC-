package me.ionar.salhack.events.render;

import me.ionar.salhack.events.MinecraftEvent;

public class EventRenderOrientCamera extends MinecraftEvent
{

}
