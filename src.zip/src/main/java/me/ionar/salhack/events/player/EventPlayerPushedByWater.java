package me.ionar.salhack.events.player;

import me.ionar.salhack.events.MinecraftEvent;

public class EventPlayerPushedByWater extends MinecraftEvent
{
    public EventPlayerPushedByWater()
    {
        super();
    }
}
