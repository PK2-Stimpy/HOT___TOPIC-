package me.ionar.salhack.events.blocks;

import me.ionar.salhack.events.MinecraftEvent;

public class EventSetOpaqueCube extends MinecraftEvent
{
}
