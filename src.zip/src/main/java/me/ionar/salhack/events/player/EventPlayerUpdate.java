package me.ionar.salhack.events.player;

import me.ionar.salhack.events.MinecraftEvent;

public class EventPlayerUpdate extends MinecraftEvent
{
    public EventPlayerUpdate()
    {
        super();
    }
}
